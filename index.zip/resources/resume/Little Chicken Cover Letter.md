# Pelle Bruinsma

#### Programmer and Game Developer :wave:

I'm Pelle, a Dutch Programmer and Game design student looking for a Programming  internship position at Little Chicken.

I've developed and published many smaller titles either myself or in collaboration within teams of 3-8 people. Playing and making games is something that really excites me. I want to reach beyond what I'm individually capable of, test and improve on my skills, work on bigger projects and on bigger teams. I believe that, given the opportunity, I could make some great contributions to your upcoming projects.

I'd love to meet with you and discuss any positions you have available. I look forward to hearing from you and thank you for your consideration.

Sincerely,

Pelle "Stupid++" Bruinsma



#### Contact

```json
{
    phone: "(+31) 06 44354294",
    email: "pelle.jorn.bruinsma@gmail.com",
    portfolio: "stupidplusplus.com",
    linkedin: "linkedin.com/in/pelle-bruinsma-9021151ab/",
    games: "stupidplusplus.itch.io",
    current_location: "Groningen, The Netherlands"
}
```

