# Pelle Bruinsma

#### Programmer and Game Developer :wave:

I'm Pelle, a Dutch Programmer and Game design student looking for an internship position at Improbable.

I've got experience developing for multiple multiplayer titles as well as a history in developing exploits and cheats for multiplayer games. Developing for multiplayer is something that truly excites me and I'd love to have a shot at developing for bigger projects than I've developed for so far.

I'd love to meet with you and discuss the Internship Software Engineering position! You can reach me at pelle.jorn.bruinsma@gmail.com or (+31) 644354294.

Looking forward to hearing from you and thank you for your consideration.

Sincerely,

Pelle Bruinsma



#### Contact

```json
{
    phone: "(+31) 06 44354294",
    email: "pelle.jorn.bruinsma@gmail.com",
    portfolio: "stupidplusplus.com",
    linkedin: "linkedin.com/in/pelle-bruinsma-9021151ab/",
    games: "stupidplusplus.itch.io",
    current_location: "Groningen, The Netherlands"
}
```

